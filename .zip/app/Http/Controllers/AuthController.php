<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    // Register
    public function register(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'NIK' => 'required|string|unique:users,NIK',
            'password' => 'required|string|min:6',
            'role' => 'required|string', // sesuaikan jika ada pilihan khusus
        ]);

        $user = User::create([
            'name' => $request->name,
            'NIK' => $request->NIK,
            'password' => \Illuminate\Support\Facades\Hash::make($request->password),
            'role' => $request->role,
        ]);

        \Illuminate\Support\Facades\Auth::login($user);

        return response()->json(['message' => 'Register & login success', 'user' => $user]);
    }

    // Login
    public function login(Request $request)
    {
        $credentials = $request->only('NIK', 'password');

        if (\Illuminate\Support\Facades\Auth::attempt($credentials)) {
            $user = \Illuminate\Support\Facades\Auth::user();
            $token = $user->createToken('auth_token')->plainTextToken;
            return response()->json(['message' => 'Login success', 'user' => $user, 'token' => $token]);
        }

        return response()->json(['error' => 'Invalid credentials'], 401);
    }

    // Logout
    public function logout(Request $request)
    {
        Auth::logout();
        return response()->json(['message' => 'Logout success']);
    }
}