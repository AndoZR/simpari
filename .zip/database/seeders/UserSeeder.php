<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        User::create([
            'name' => 'Budi Santoso',
            'NIK' => '3201010101010001',
            'password' => Hash::make('password123'),
            'role' => 'masyarakat',
        ]);

        User::create([
            'name' => 'Siti Aminah',
            'NIK' => '3201010101010002',
            'password' => Hash::make('password123'),
            'role' => 'pemungut',
        ]);

        User::create([
            'name' => 'Admin Bendahara',
            'NIK' => '3201010101010003',
            'password' => Hash::make('password123'),
            'role' => 'bendahara',
        ]);

        User::create([
            'name' => 'Admin Kecamatan',
            'NIK' => '3201010101010004',
            'password' => Hash::make('password123'),
            'role' => 'kecamatan',
        ]);
    }
}
