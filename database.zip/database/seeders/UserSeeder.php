<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Masyarakat;
use App\Models\Pemungut;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        User::create([
            'nik' => '3509200904020002',
            'password' => Hash::make('123123123'),
            'role' => 'masyarakat',
        ]);

        User::create([
            'nik' => '3509200904020001',
            'password' => Hash::make('123123123'),
            'role' => 'masyarakat',
        ]);

        User::create([
            // 'name' => 'Siti Aminah',
            'nik' => '3201010101010002',
            'password' => Hash::make('123123123'),
            'role' => 'pemungut',
        ]);

        Pemungut::create([
            'nama' => 'Siti Aminah',
            'user_id'  => 3,
            'telepon' => '081234567891',
            'alamat' => 'Jl. Raya No. 1321, Desa Sukamundur',
        ]);

        Masyarakat::create([
            'nama' => 'Ando Royan',
            'nop' => '123123123321',
            'user_id'  => 1,
            'telepon' => '081234567890',
            'alamat' => 'Jl. Raya No. 123, Desa Sukamaju',
            'pemungut_id' => 1,
        ]);

        Masyarakat::create([
            'nama' => 'John Smith',
            'nop' => '123123123311',
            'user_id'  => 2,
            'telepon' => '081234567891',
            'alamat' => 'Jl. Raya No. 1321, Desa Sukamundur',
            'pemungut_id' => 1,
        ]);

        User::create([
            // 'name' => 'Admin Bendahara',
            'nik' => '3201010101010003',
            'password' => Hash::make('123123123'),
            'role' => 'admin_kecamatan',
        ]);

        User::create([
            // 'name' => 'Admin Kecamatan',
            'nik' => '3201010101010004',
            'password' => Hash::make('123123123'),
            'role' => 'admin_desa',
        ]);
    }
}
